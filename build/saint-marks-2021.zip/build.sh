rm -R build/
zip -r saint-marks-2021.zip *
mkdir build
mv saint-marks-2021.zip build/