

<?php global $EM_Event; ?>
<?php echo $EM_Event->output_single(); ?>

<?php get_footer(); ?>