window.addEventListener('load', function() {
  setupEventVideo(event_vars);
  setupLiveVideo();
});

function setupLiveVideo() {
  var el = document.getElementById('live-video');
  if(el) {
    function onPlayerReady(event) {
      event.target.playVideo();
    }

    new YT.Player('live-video', {
      playerVars: {
        'playsinline': 1
      },
      events: {
        'onReady': onPlayerReady
      }
    });
  }
}

function setupEventVideo(event_vars) {
  function onPlayerReady(event) {
    event.target.playVideo();
  }

  var url = event_vars.event.event_attributes.service_video;
  if(url) {
    var regExp = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#&?]*).*/;
    var match = url.match(regExp);
    var id = (match&&match[7].length==11)? match[7] : false;

    var player = new YT.Player('player', {
      width: '100%',
      height: '100%',
      videoId: id,
      playerVars: {
        'playsinline': 1
      },
      events: {
        'onReady': onPlayerReady
      }
    });
  }
}